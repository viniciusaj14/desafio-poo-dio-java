# Desafio POO DIO - Bootcamp Java

Projeto criado para o desafio **Abstraindo um Bootcamp Usando Orientação a Objetos em Java**.

## Conceitos aplicados

- Abstração
- Encapsulamento
- Herança
- Polimorfismo
- Collections
- Stream API
- Optional

## Como executar

1. Extraia o arquivo ZIP.
2. Abra a pasta no IntelliJ IDEA.
3. Configure o JDK 17 ou 21.
4. Execute o arquivo `Main.java`.
